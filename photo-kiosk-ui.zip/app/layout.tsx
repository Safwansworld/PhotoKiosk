import React from "react"
import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'PhotoPoint | Self-Service Photo Kiosk',
  description: 'Government-grade photo capture and printing. Studio lighting, auto-retouching, and instant prints.',
    generator: 'v0.app'
}

export const viewport: Viewport = {
  width: 1920,
  height: 1080,
  initialScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
