"use client"

import { useState } from "react"
import { AttractScreen } from "@/components/kiosk/attract-screen"
import { CaptureScreen } from "@/components/kiosk/capture-screen"
import { UploadScreen } from "@/components/kiosk/upload-screen"
import { EditScreen } from "@/components/kiosk/edit-screen"
import { PaymentScreen } from "@/components/kiosk/payment-screen"
import { StatusBar } from "@/components/kiosk/status-bar"

export type KioskScreen = "attract" | "capture" | "upload" | "edit" | "payment"

export interface PhotoData {
  imageUrl: string | null
  source: "camera" | "upload" | null
}

export default function PhotoPointKiosk() {
  const [currentScreen, setCurrentScreen] = useState<KioskScreen>("attract")
  const [language, setLanguage] = useState<"ENG" | "MAL">("ENG")
  const [photoData, setPhotoData] = useState<PhotoData>({
    imageUrl: null,
    source: null,
  })

  const handleCapture = (imageUrl: string) => {
    setPhotoData({ imageUrl, source: "camera" })
    setCurrentScreen("edit")
  }

  const handleUpload = (imageUrl: string) => {
    setPhotoData({ imageUrl, source: "upload" })
    setCurrentScreen("edit")
  }

  const handlePaymentComplete = () => {
    // Reset after printing
    setTimeout(() => {
      setPhotoData({ imageUrl: null, source: null })
      setCurrentScreen("attract")
    }, 5000)
  }

  const handleBack = () => {
    if (currentScreen === "capture" || currentScreen === "upload") {
      setCurrentScreen("attract")
    } else if (currentScreen === "edit") {
      setCurrentScreen(photoData.source === "camera" ? "capture" : "upload")
    } else if (currentScreen === "payment") {
      setCurrentScreen("edit")
    }
  }

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-[#F9FAFB]">
      {/* Screen Content */}
      <div className="h-full w-full">
        {currentScreen === "attract" && (
          <AttractScreen
            onStartCamera={() => setCurrentScreen("capture")}
            onUploadFile={() => setCurrentScreen("upload")}
            language={language}
          />
        )}
        {currentScreen === "capture" && (
          <CaptureScreen
            onCapture={handleCapture}
            onBack={handleBack}
            language={language}
          />
        )}
        {currentScreen === "upload" && (
          <UploadScreen
            onUpload={handleUpload}
            onBack={handleBack}
            language={language}
          />
        )}
        {currentScreen === "edit" && (
          <EditScreen
            photoData={photoData}
            onProceedToPayment={() => setCurrentScreen("payment")}
            onBack={handleBack}
            language={language}
          />
        )}
        {currentScreen === "payment" && (
          <PaymentScreen
            photoData={photoData}
            onComplete={handlePaymentComplete}
            onBack={handleBack}
            language={language}
          />
        )}
      </div>

      {/* Global Status Bar */}
      <StatusBar
        language={language}
        onLanguageChange={setLanguage}
        showBack={currentScreen !== "attract"}
        onBack={handleBack}
      />
    </main>
  )
}
