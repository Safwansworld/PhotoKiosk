"use client"

import React from "react"

import { useState } from "react"
import { Check, Lock, Sparkles, Sun, Crop, ArrowRight } from "lucide-react"
import type { PhotoData } from "@/app/page"

interface EditScreenProps {
  photoData: PhotoData
  onProceedToPayment: () => void
  onBack: () => void
  language: "ENG" | "MAL"
}

interface Toggle {
  id: string
  icon: React.ReactNode
  label: string
  description: string
  enabled: boolean
  locked?: boolean
}

export function EditScreen({
  photoData,
  onProceedToPayment,
  onBack,
  language,
}: EditScreenProps) {
  const [toggles, setToggles] = useState<Toggle[]>([
    {
      id: "background",
      icon: <Sparkles className="h-6 w-6" />,
      label: language === "ENG" ? "Remove Background" : "പശ്ചാത്തലം നീക്കം ചെയ്യുക",
      description: language === "ENG" ? "AI-powered background removal" : "AI പവർഡ് ബാക്ക്ഗ്രൗണ്ട് നീക്കൽ",
      enabled: true,
    },
    {
      id: "lighting",
      icon: <Sun className="h-6 w-6" />,
      label: language === "ENG" ? "Fix Lighting" : "ലൈറ്റിംഗ് ശരിയാക്കുക",
      description: language === "ENG" ? "Auto-adjust brightness & contrast" : "ബ്രൈറ്റ്‌നെസ് & കോൺട്രാസ്റ്റ് ഓട്ടോ-അഡ്ജസ്റ്റ്",
      enabled: true,
    },
    {
      id: "crop",
      icon: <Crop className="h-6 w-6" />,
      label: language === "ENG" ? "Auto-Crop to Passport Size" : "പാസ്‌പോർട്ട് സൈസിലേക്ക് ഓട്ടോ-ക്രോപ്പ്",
      description: language === "ENG" ? "35mm × 45mm official format" : "35mm × 45mm ഔദ്യോഗിക ഫോർമാറ്റ്",
      enabled: true,
      locked: true,
    },
  ])

  const content = {
    ENG: {
      title: "AI Photo Lab",
      subtitle: "Smart enhancements applied",
      preview: "Preview",
      document: "Passport Photo",
      dimensions: "35mm × 45mm",
      proceedButton: "Looks Good — Pay ₹100",
      toggleLabel: {
        on: "ON",
        off: "OFF",
        locked: "Required",
      },
    },
    MAL: {
      title: "AI ഫോട്ടോ ലാബ്",
      subtitle: "സ്മാർട്ട് മെച്ചപ്പെടുത്തലുകൾ പ്രയോഗിച്ചു",
      preview: "പ്രിവ്യൂ",
      document: "പാസ്‌പോർട്ട് ഫോട്ടോ",
      dimensions: "35mm × 45mm",
      proceedButton: "നല്ലതായി തോന്നുന്നു — ₹100 അടയ്ക്കുക",
      toggleLabel: {
        on: "ഓൺ",
        off: "ഓഫ്",
        locked: "ആവശ്യമാണ്",
      },
    },
  }

  const t = content[language]

  const handleToggle = (id: string) => {
    setToggles((prev) =>
      prev.map((toggle) =>
        toggle.id === id && !toggle.locked
          ? { ...toggle, enabled: !toggle.enabled }
          : toggle
      )
    )
  }

  return (
    <div className="flex h-full w-full pb-24">
      {/* Left Side - Photo Preview */}
      <div className="flex w-1/2 flex-col items-center justify-center bg-[#F3F4F6] p-12">
        <div className="w-full max-w-lg">
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wider text-[#6B7280]">
            {t.preview}
          </h2>

          {/* Document Simulation Frame */}
          <div className="relative rounded-3xl bg-white p-8 soft-shadow">
            {/* Document Header */}
            <div className="mb-6 flex items-center justify-between border-b border-[#E5E7EB] pb-4">
              <div>
                <p className="text-lg font-bold text-[#0F172A]">{t.document}</p>
                <p className="text-sm text-[#6B7280]">{t.dimensions}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#ECFDF5]">
                <Check className="h-5 w-5 text-[#059669]" />
              </div>
            </div>

            {/* Photo Frame */}
            <div className="relative mx-auto aspect-[35/45] w-64 overflow-hidden rounded-xl border-4 border-[#E5E7EB] bg-gradient-to-b from-[#E0E7FF] to-[#C7D2FE]">
              {/* Placeholder face silhouette */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-32 w-24 rounded-t-full bg-[#0F172A]/20" />
              </div>
              
              {/* Enhancement indicators */}
              {toggles[0].enabled && (
                <div className="absolute bottom-2 left-2 rounded-full bg-white/90 px-2 py-1">
                  <span className="text-xs font-medium text-[#059669]">BG Removed</span>
                </div>
              )}
              {toggles[1].enabled && (
                <div className="absolute bottom-2 right-2 rounded-full bg-white/90 px-2 py-1">
                  <span className="text-xs font-medium text-[#2563EB]">Enhanced</span>
                </div>
              )}
            </div>

            {/* Crop Guidelines */}
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className="h-px w-8 bg-[#E5E7EB]" />
              <span className="text-xs text-[#6B7280]">Auto-cropped to specifications</span>
              <div className="h-px w-8 bg-[#E5E7EB]" />
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - AI Tools */}
      <div className="flex w-1/2 flex-col items-center justify-center bg-white p-12">
        <div className="w-full max-w-lg">
          {/* Header */}
          <div className="mb-10">
            <h1 className="mb-2 text-4xl font-bold tracking-tight text-[#0F172A]">
              {t.title}
            </h1>
            <p className="text-xl text-[#6B7280]">{t.subtitle}</p>
          </div>

          {/* Smart Toggles */}
          <div className="mb-10 space-y-4">
            {toggles.map((toggle) => (
              <div
                key={toggle.id}
                className={`flex items-center justify-between rounded-2xl border-2 p-5 transition-all ${
                  toggle.enabled
                    ? "border-[#2563EB]/20 bg-[#EFF6FF]"
                    : "border-[#E5E7EB] bg-white"
                }`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                      toggle.enabled
                        ? "bg-[#2563EB] text-white"
                        : "bg-[#F3F4F6] text-[#6B7280]"
                    }`}
                  >
                    {toggle.icon}
                  </div>
                  <div>
                    <p className="font-semibold text-[#0F172A]">{toggle.label}</p>
                    <p className="text-sm text-[#6B7280]">{toggle.description}</p>
                  </div>
                </div>

                {/* Toggle Switch */}
                {toggle.locked ? (
                  <div className="flex items-center gap-2 rounded-full bg-[#F3F4F6] px-4 py-2">
                    <Lock className="h-4 w-4 text-[#6B7280]" />
                    <span className="text-sm font-medium text-[#6B7280]">
                      {t.toggleLabel.locked}
                    </span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleToggle(toggle.id)}
                    className={`relative h-8 w-16 rounded-full transition-colors ${
                      toggle.enabled ? "bg-[#2563EB]" : "bg-[#E5E7EB]"
                    }`}
                    aria-label={`Toggle ${toggle.label}`}
                  >
                    <div
                      className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-transform ${
                        toggle.enabled ? "translate-x-9" : "translate-x-1"
                      }`}
                    />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Proceed to Payment Button */}
          <button
            onClick={onProceedToPayment}
            className="group flex h-[88px] w-full items-center justify-between rounded-2xl bg-[#059669] px-8 text-white transition-all hover:bg-[#047857] active:scale-[0.98] soft-shadow"
          >
            <span className="text-2xl font-semibold">{t.proceedButton}</span>
            <ArrowRight className="h-7 w-7 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </div>
  )
}
