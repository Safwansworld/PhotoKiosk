"use client"

import React from "react"

import { useState, useRef, useEffect } from "react"
import { Usb, MessageCircle, Smartphone, QrCode, Check } from "lucide-react"
import { QRCodeSVG } from "qrcode.react"

interface UploadScreenProps {
  onUpload: (imageUrl: string) => void
  onBack: () => void
  language: "ENG" | "MAL"
}

export function UploadScreen({
  onUpload,
  onBack,
  language,
}: UploadScreenProps) {
  const [usbConnected, setUsbConnected] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const content = {
    ENG: {
      title: "Choose Upload Method",
      subtitle: "Select how you'd like to transfer your photo",
      mobile: {
        headline: "Mobile Transfer",
        subtext: "Scan to Upload from Phone",
        note: "No App Needed",
        preferred: "Recommended",
      },
      whatsapp: {
        headline: "WhatsApp",
        subtext: "Send Photo to",
        number: "+91 98765 43210",
      },
      usb: {
        headline: "USB / Memory Card",
        subtext: "Insert Drive Below",
        connected: "Device Connected",
        select: "Select File",
      },
    },
    MAL: {
      title: "അപ്‌ലോഡ് രീതി തിരഞ്ഞെടുക്കുക",
      subtitle: "നിങ്ങളുടെ ഫോട്ടോ കൈമാറാൻ ഒരു വഴി തിരഞ്ഞെടുക്കുക",
      mobile: {
        headline: "മൊബൈൽ ട്രാൻസ്ഫർ",
        subtext: "ഫോണിൽ നിന്ന് അപ്‌ലോഡ് ചെയ്യാൻ സ്കാൻ ചെയ്യുക",
        note: "ആപ്പ് ആവശ്യമില്ല",
        preferred: "ശുപാർശ ചെയ്യുന്നു",
      },
      whatsapp: {
        headline: "WhatsApp",
        subtext: "ഫോട്ടോ അയയ്ക്കുക",
        number: "+91 98765 43210",
      },
      usb: {
        headline: "USB / മെമ്മറി കാർഡ്",
        subtext: "ഡ്രൈവ് താഴെ ചേർക്കുക",
        connected: "ഉപകരണം ബന്ധിപ്പിച്ചു",
        select: "ഫയൽ തിരഞ്ഞെടുക്കുക",
      },
    },
  }

  const t = content[language]

  // Simulate USB detection
  useEffect(() => {
    const timer = setTimeout(() => {
      setUsbConnected(true)
    }, 3000)
    return () => clearTimeout(timer)
  }, [])

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string
        onUpload(imageUrl)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleCardClick = (type: "mobile" | "whatsapp" | "usb") => {
    if (type === "usb" && usbConnected) {
      fileInputRef.current?.click()
    }
    // For demo, simulate upload after a delay for other methods
    if (type === "mobile" || type === "whatsapp") {
      setTimeout(() => {
        onUpload("/api/placeholder/600/800")
      }, 2000)
    }
  }

  return (
    <div className="flex h-full w-full flex-col items-center justify-center pb-24 px-12">
      {/* Header */}
      <div className="mb-12 text-center">
        <h1 className="mb-3 text-5xl font-bold tracking-tight text-[#0F172A]">
          {t.title}
        </h1>
        <p className="text-xl text-[#6B7280]">{t.subtitle}</p>
      </div>

      {/* Upload Method Cards */}
      <div className="flex w-full max-w-6xl items-stretch justify-center gap-8">
        {/* Card 1: Mobile Transfer (Primary - 20% larger) */}
        <div
          onClick={() => handleCardClick("mobile")}
          className="group relative flex w-[420px] cursor-pointer flex-col items-center rounded-3xl bg-white p-10 transition-all hover:scale-[1.02] active:scale-[0.98] soft-shadow"
        >
          {/* Preferred Badge */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2">
            <div className="rounded-full bg-[#2563EB] px-4 py-1.5">
              <span className="text-sm font-semibold text-white">
                {t.mobile.preferred}
              </span>
            </div>
          </div>

          {/* QR Code */}
          <div className="mb-8 rounded-2xl border-4 border-[#F3F4F6] p-4">
            <QRCodeSVG
              value="https://photopoint.gov.in/upload/session/abc123"
              size={180}
              level="H"
              bgColor="#FFFFFF"
              fgColor="#0F172A"
            />
          </div>

          {/* Icon */}
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#EFF6FF]">
            <Smartphone className="h-8 w-8 text-[#2563EB]" />
          </div>

          {/* Text */}
          <h3 className="mb-2 text-2xl font-bold text-[#0F172A]">
            {t.mobile.headline}
          </h3>
          <p className="mb-3 text-center text-lg text-[#6B7280]">
            {t.mobile.subtext}
          </p>
          <span className="rounded-full bg-[#F3F4F6] px-4 py-1.5 text-sm font-medium text-[#6B7280]">
            {t.mobile.note}
          </span>

          {/* Hover Glow */}
          <div className="absolute inset-0 rounded-3xl border-2 border-transparent transition-colors group-hover:border-[#2563EB]/30" />
        </div>

        {/* Card 2: WhatsApp */}
        <div
          onClick={() => handleCardClick("whatsapp")}
          className="group flex w-[340px] cursor-pointer flex-col items-center rounded-3xl bg-white p-10 transition-all hover:scale-[1.02] active:scale-[0.98] soft-shadow"
        >
          {/* WhatsApp Logo */}
          <div className="mb-8 flex h-24 w-24 items-center justify-center rounded-full bg-[#25D366]">
            <MessageCircle className="h-12 w-12 text-white" fill="white" />
          </div>

          {/* Text */}
          <h3 className="mb-2 text-2xl font-bold text-[#0F172A]">
            {t.whatsapp.headline}
          </h3>
          <p className="mb-3 text-center text-lg text-[#6B7280]">
            {t.whatsapp.subtext}
          </p>
          <span className="rounded-xl bg-[#F3F4F6] px-5 py-2.5 font-mono text-lg font-semibold text-[#0F172A]">
            {t.whatsapp.number}
          </span>

          {/* Hover Border */}
          <div className="absolute inset-0 rounded-3xl border-2 border-transparent transition-colors group-hover:border-[#25D366]/30" />
        </div>

        {/* Card 3: USB */}
        <div
          onClick={() => handleCardClick("usb")}
          className="group flex w-[340px] cursor-pointer flex-col items-center rounded-3xl bg-white p-10 transition-all hover:scale-[1.02] active:scale-[0.98] soft-shadow"
        >
          {/* USB Icon with Status */}
          <div className="relative mb-8">
            <div className={`flex h-24 w-24 items-center justify-center rounded-full ${
              usbConnected ? "bg-[#ECFDF5]" : "bg-[#F3F4F6]"
            } transition-colors`}>
              <Usb className={`h-12 w-12 ${
                usbConnected ? "text-[#059669]" : "text-[#6B7280]"
              } transition-colors`} />
            </div>
            {/* Connection indicator */}
            {usbConnected && (
              <div className="absolute -right-1 -top-1 flex h-8 w-8 items-center justify-center rounded-full bg-[#059669]">
                <Check className="h-5 w-5 text-white" />
              </div>
            )}
          </div>

          {/* Text */}
          <h3 className="mb-2 text-2xl font-bold text-[#0F172A]">
            {t.usb.headline}
          </h3>
          <p className="mb-3 text-center text-lg text-[#6B7280]">
            {usbConnected ? t.usb.connected : t.usb.subtext}
          </p>
          
          {usbConnected && (
            <button className="rounded-xl bg-[#0F172A] px-6 py-3 font-semibold text-white transition-colors hover:bg-[#1e293b]">
              {t.usb.select}
            </button>
          )}

          {/* Pulse animation when not connected */}
          {!usbConnected && (
            <div className="h-2 w-24 animate-pulse rounded-full bg-[#E5E7EB]" />
          )}

          {/* Hover Border */}
          <div className="absolute inset-0 rounded-3xl border-2 border-transparent transition-colors group-hover:border-[#0F172A]/20" />
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
        aria-label="Select image file"
      />
    </div>
  )
}
